from email.mime import image

from django.shortcuts import render
from django.contrib.messages.constants import SUCCESS
from django.contrib.auth.hashers import make_password , check_password
from django.contrib import messages
from django.shortcuts import redirect, render
from . models import  RegUser, Recipe
from django.utils import timezone
from django.core.files.storage import FileSystemStorage
# Create your views here.

def seerecipe(request,id):
    recipe = Recipe.objects.get(pk=id)
    return render(request, 'Users/seerecipe.html', {"item":recipe})


def Index(request):
    if request.method == 'POST':
        searched=request.POST['searched']
        recipes = Recipe.objects.filter(name = searched )#.filter(ingredient=searched)
        if recipes.exists():
                 return render(request, 'Users/index.html', {"searched":searched,"item":recipes})
        elif recipes=="":
            recipe = Recipe.objects.all()
            return render(request, 'Users/index.html', {"item":recipe})
        elif  not recipes.count():
            messages.add_message(request, messages.SUCCESS, 'Sorry Not Found Try Something Else')
    recipe = Recipe.objects.all()
    return render(request, 'Users/index.html', {"item":recipe})


def registration(request):
    if request.method == 'POST':
        checkemail = RegUser.objects.filter(emailid = request.POST['txtemail'])
        if checkemail.count() > 0:
            messages.add_message(request, messages.WARNING, 'Email Id is All Ready Exists')
            return render(request, 'Users/registration.html')
        else:
            insertQuery = RegUser(fullname = request.POST['txtfname'],
                                    emailid = request.POST['txtemail'],
                                    password = make_password (request.POST['txtpass']),
                                    mobile = request.POST['txtmobile'],
                                    createdate = timezone.now())
            insertQuery.save()
            messages.add_message(request, messages.SUCCESS, 'Your account has been created')
        return render(request, 'Users/registration.html')
    return render(request, 'Users/registration.html')


def login(request):
    if request.method == 'POST':
        loginQuery = RegUser.objects.filter(emailid = request.POST['email']).values_list('id','password')
        passcheck = loginQuery[0][1]
        if loginQuery.count() > 0 and check_password(request.POST['password'],passcheck):
            loginQuery[0][0]
            request.session['logged'] = loginQuery[0][0]
            return redirect('userdashboard')
        else:
            return render(request, 'Users/login.html', {'msginvalid' : 'username and password is invalid'})
    return render(request, 'Users/login.html')
 

def userdashboard(request):
    if request.session.has_key('logged'):
        udata = {'showdata': RegUser.objects.get(pk = request.session['logged'])}
        context = {'showRecipeData' : Recipe.objects.filter(user_id  = request.session['logged']), 'udata':udata}
        return render(request, 'Users/userdashboard.html',context )
    else:
        return redirect('login')

def managerecipe(request):
    if request.session.has_key('logged'):
        if request.method == 'POST' and request.FILES['myfile']:
                user_id  = request.session['logged']
                myfile = request.FILES['myfile']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                insertQuery = Recipe (user_id  = request.session['logged'],
                                name = request.POST['txtname'],
                                desc = request.POST['txtdesc'],
                                ingredient = request.POST['txting'],
                                direction = request.POST['txtdir'],
                                image=filename,
                                CreateDate = timezone.now())
                insertQuery.save()
                messages.add_message(request, messages.SUCCESS, 'Your account has been created')
        return render(request, 'Users/managerecipe.html')
    else:
        return redirect('login')

def manageprofile(request):
    if request.method == 'POST':
        userEdit = RegUser.objects.get(pk = request.session['logged'])
        userEdit.fullname = request.POST['txtname']
        userEdit.emailid = request.POST['txtemail']
        userEdit.password = make_password (request.POST['txtpass']),
        userEdit.mobile = request.POST['txtmobile']
        userEdit.save()
        return redirect('userdashboard')
    valueShow = RegUser.objects.get(pk = request.session['logged'])
    context = {'valueShow' : valueShow}
    return render(request, 'Users/manageprofile.html', context)

def editrecipe(request,id):
    if request.session.has_key('logged'):
        if request.method == 'POST' and request.FILES['myfile']:
                user_id  = RegUser.objects.get(pk = request.session['logged'])
                myfile = request.FILES['myfile']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                #r = Review.objects.get(pk=request.POST["txtpkid"])
                updateQuery = Recipe.objects.get(pk=request.POST["txtpkid"])
                updateQuery.user= user_id 
                updateQuery.name = request.POST['txtname']
                updateQuery.desc = request.POST['txtdesc']
                updateQuery.ingredient = request.POST['txting']
                updateQuery.direction = request.POST['txtdir']
                updateQuery.image=filename
                updateQuery.CreateDate=timezone.now()
                updateQuery.save()
                return redirect('userdashboard')
        else:
            valueShow = Recipe.objects.get(pk=id)
            return render(request, 'Users/editrecipe.html',{"valueShow":valueShow})
    else:
        return redirect('login')

def userrecipe(request,id):
    if request.session.has_key('logged'): 
            recipe = Recipe.objects.get(pk=id)
            return render(request, 'Users/userrecipe.html', {"item":recipe})
    else:
        return redirect('login')
        
def deleterecipe(request,id):
    if request.session.has_key('logged'): 
            r = Recipe.objects.get(pk=id)
            r.delete()
            return redirect('userdashboard')
    else:
        return redirect('login')

def logOut(request):
    del request.session['logged']
    return redirect('/')