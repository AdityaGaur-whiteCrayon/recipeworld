
from django.urls import path,include
from .import views



urlpatterns = [
    path("deleterecipe/<int:id>/",views.deleterecipe,name="deleterecipe"),
    path("userrecipe/<int:id>/",views.userrecipe,name="userrecipe"),
    path("<int:id>/",views.seerecipe,name="seerecipe"),
    path("editrecipe/<int:id>/",views.editrecipe,name="editrecipe"),
    path("logOut",views.logOut,name="logOut"),
    path("manageprofile",views.manageprofile,name="manageprofile"),
    path("managerecipe",views.managerecipe,name="managerecipe"),
    path("userdashboard",views.userdashboard,name="userdashboard"),
    path("registration",views.registration,name="registration"),
    path("login",views.login,name="login"),
    path("",views.Index,name="Index"),
    
    
    


]
