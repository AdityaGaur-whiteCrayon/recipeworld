from django.db import models
from ckeditor.fields import RichTextField

class RegUser(models.Model):
	fullname = models.CharField(max_length=50,default='')
	emailid = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	mobile = models.CharField(max_length=50)
	createdate=models.DateTimeField()
	


	
	
class Recipe(models.Model):
    user=models.ForeignKey(RegUser,on_delete=models.CASCADE ,blank=True, null=True)
    name=models.CharField(max_length=50)
    desc=models.CharField(max_length=500)
    #ingredient=models.CharField(max_length=500)
    ingredient=RichTextField(max_length=600)
    direction=models.CharField(max_length=800)
    CreateDate= models.DateTimeField()
    image=models.ImageField(upload_to="static/images/", default='https://www.everestkitchenpa.com/assets/images/menuShortCuts/momoShortCut.jpg')


           