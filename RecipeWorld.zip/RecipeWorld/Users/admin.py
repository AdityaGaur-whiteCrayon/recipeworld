from django.contrib import admin

from .models import RegUser, Recipe

@admin.register(RegUser)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'fullname','emailid','password','mobile','createdate',]




@admin.register(Recipe)
class UserAdmin(admin.ModelAdmin):
    list_display = ['id', 'user','name','desc','ingredient','direction','CreateDate','image']
